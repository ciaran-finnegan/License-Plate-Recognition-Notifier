#!/bin/bash

# Set your AWS region and profile (if not the default profile)
AWS_REGION="eu-west-1"
AWS_PROFILE="default"

# Set your parameter values
plate_recognizer_token="bfeb12f7144f5ba60362a924f91730dd8eca4595"
ses_sender_email="test@bot.riskscope-consulting.com"
twilio_from_phone_number="+17758710065"
twilio_to_phone_number="+353879799033"
twilio_account_sid="ACc6a3e4b80dccf168cbf90237463d9c70"
twilio_auth_token="927d4ecfe3c07a6fd5207b20468dc0ab"
s3_bucket_name="authorised-licence-plates"
s3_file_key="authorised_licence_plates.csv"
fuzzy_match_threshold="80"  # This is a string to be consistent with Parameter Store

# Set the parameters in the Parameter Store
aws ssm put-parameter --name "/LicensePlateRecognition/PlateRecognizerToken" --value "$plate_recognizer_token" --type "SecureString" --region $AWS_REGION --profile $AWS_PROFILE
aws ssm put-parameter --name "/LicensePlateRecognition/SESSenderEmail" --value "$ses_sender_email" --type "String" --region $AWS_REGION --profile $AWS_PROFILE
aws ssm put-parameter --name "/LicensePlateRecognition/TwilioAccountSID" --value "$twilio_account_sid" --type "SecureString" --region $AWS_REGION --profile $AWS_PROFILE
aws ssm put-parameter --name "/LicensePlateRecognition/TwilioAuthToken" --value "$twilio_auth_token" --type "SecureString" --region $AWS_REGION --profile $AWS_PROFILE
aws ssm put-parameter --name "/LicensePlateRecognition/TwilioFromPhoneNumber" --value "$twilio_from_phone_number" --type "String" --region $AWS_REGION --profile $AWS_PROFILE
aws ssm put-parameter --name "/LicensePlateRecognition/TwilioToPhoneNumber" --value "$twilio_to_phone_number" --type "String" --region $AWS_REGION --profile $AWS_PROFILE
aws ssm put-parameter --name "/LicensePlateRecognition/S3BucketName" --value "$s3_bucket_name" --type "String" --region $AWS_REGION --profile $AWS_PROFILE
aws ssm put-parameter --name "/LicensePlateRecognition/S3FileKey" --value "$s3_file_key" --type "String" --region $AWS_REGION --profile $AWS_PROFILE
aws ssm put-parameter --name "/LicensePlateRecognition/FuzzyMatchThreshold" --value "$fuzzy_match_threshold" --type "String" --region $AWS_REGION --profile $AWS_PROFILE

echo "Parameters set in AWS Systems Manager Parameter Store."
